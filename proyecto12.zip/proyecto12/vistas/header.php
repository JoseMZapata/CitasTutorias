<header class="HeaderPrincipal">
        <div class="HeaderPrincipal--logo">
            <div class="HeaderPrincipal--logo1 comun">
                <a href="vistaalumno.php"><center><img src="img/logo_png_blanco.png" alt="Logo de la empresa"></center></a>
            </div>
            
        </div>
        <div class="Buscador">
            <input class="BuscadorInformacion" type="search" placeholder="Busqueda">
            <div class="botonbusqueda">
                <i class="fas fa-search"></i>
            </div>
        </div>
        <div class="HeaderPrincipal--Navegacion comun">
            <button class="link1" id="botonopciones" type="submit">
                <center><img class="Imagenprofile" src="img/icons8-account-64.png" alt="ImagenPerfil"></center>
            </button>
            
        </div>
        <div class="OpcionesUsuario">
            <div class="OpcionesUsuarioPerfil12">
                <section id="Perfil12">
                    
                </section>
            </div>
            <div class="OpcionesUsuarioAsesoriasAgendadas">
                <section id="AsesoriasAgendadas">

                </section>
            </div>
            <div class="OpcionesUsuarioCerrarSesion">
                <section id="CerrarSesion">

                </section>
            </div>
        </div>
    </header>
    <script src="js/opciones.js"></script>
