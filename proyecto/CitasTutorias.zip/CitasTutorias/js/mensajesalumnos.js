const division = document.querySelector('.Mensajes_Del_Curso');
const boton2= document.querySelector('#MensajeCurso')
boton2.addEventListener('click',function(evento){
    
    function mostrarmensajes(){
        const divisionmensajes=document.createElement('div')
        divisionmensajes.classList.add('MensajesDelCurso')
    
    }
})